package GestionHotel;
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class FenetreGestionHotel extends JFrame implements Serializable{
	

	private static final long serialVersionUID = 1L;
	private CardLayout FenetreGestionOrganiser;
	private JPanel PanneauFenetreGestion;
	public JPanel carreChambre;

	
	public FenetreGestionHotel() {
		
		FenetreGestionOrganiser = new CardLayout();
		PanneauFenetreGestion = new JPanel(FenetreGestionOrganiser);
		// TODO Auto-generated constructor stub
		setLayout(new BorderLayout());
		
		
		// NOUVEAU
		// Panneau d'infos hotel
		JPanel infosZone = new JPanel();
		infosZone.setLayout(new BorderLayout());
		
		// Grille d'abonnements
		JPanel zoneInfosAbonnements = new JPanel();
		zoneInfosAbonnements.setLayout(new GridLayout(1,2));
		
		JPanel jourTarifsAbonnements = new JPanel();
		jourTarifsAbonnements.setLayout(new GridLayout(4,2));
		jourTarifsAbonnements.add(new JLabel(" Journée : "));
		jourTarifsAbonnements.add(new JLabel(" 2 500 F CFA: "));
		jourTarifsAbonnements.add(new JLabel(" Semaine : "));
		jourTarifsAbonnements.add(new JLabel(" 17 500 F CFA: "));
		jourTarifsAbonnements.add(new JLabel(" Mois : "));
		jourTarifsAbonnements.add(new JLabel(" 75 000 F CFA: "));
		jourTarifsAbonnements.add(new JLabel(" Année : "));
		jourTarifsAbonnements.add(new JLabel(" 1 000 000 F CFA: "));
		
		
		JPanel abonnementsTitre = new JPanel();JPanel abonnementsTitre1 = new JPanel();JPanel abonnementsTitre2 = new JPanel();
		
		abonnementsTitre.setLayout(new BorderLayout());abonnementsTitre1.setLayout(new BorderLayout());abonnementsTitre2.setLayout(new BorderLayout());
		abonnementsTitre.add(new JLabel("Listes Abonnements Disponibles Dans Hotel Celine"), BorderLayout.CENTER);
		
		
		zoneInfosAbonnements.add(abonnementsTitre);
		zoneInfosAbonnements.add(abonnementsTitre1);
		zoneInfosAbonnements.add(abonnementsTitre2);
		zoneInfosAbonnements.add(jourTarifsAbonnements);
		
		// Grille de chambres
		
		JPanel infosPanneauChambre = new JPanel();
		infosPanneauChambre.setLayout(new BorderLayout());
		
		JPanel titrePanneauChambre = new JPanel();
		titrePanneauChambre.setLayout(new BoxLayout(titrePanneauChambre, BoxLayout.Y_AXIS));
		titrePanneauChambre.add(new JLabel("Chambres Occupées et Non Occupées"));
		
		
		titrePanneauChambre.add(new JLabel("\n Celles Occupées en Rouge"));
		titrePanneauChambre.add(new JLabel("\n Celles Non Occupées en Vert"));
		infosPanneauChambre.add(titrePanneauChambre, BorderLayout.CENTER);

		
		carreChambre = new JPanel();
		carreChambre.setLayout(new GridLayout(10, 15));
		for(int i=1;i<=150;i++) {
			JPanel contenantCarreChambre = new JPanel();
			contenantCarreChambre.setBorder(BorderFactory.createLineBorder(Color.GREEN)); // On créer des cases avec des contours verts
			contenantCarreChambre.add(new JLabel(String.valueOf(i)));
			carreChambre.add(contenantCarreChambre);
		}
		
		JScrollPane defilementChambre = new JScrollPane();
		carreChambre.add(defilementChambre, BorderLayout.CENTER);
		
		JPanel derniereChambreO = new JPanel();
		derniereChambreO.add(new JLabel("Dernière chambre libérée : "));
		infosPanneauChambre.add(defilementChambre, BorderLayout.WEST);
		
		// Grilles de suites VIP
		JPanel suitesCarre = new JPanel();
		suitesCarre.setLayout(new GridLayout(3,10));
		for(int i=1;i<11;i++) {
			JPanel contenantSuiteCarre = new JPanel();
			contenantSuiteCarre.setBorder(BorderFactory.createLineBorder(Color.YELLOW));
			contenantSuiteCarre.add(new JLabel(" SALLE VIP " + i));
			suitesCarre.add(contenantSuiteCarre);
		}
		
		infosZone.add(zoneInfosAbonnements,BorderLayout.NORTH);
		infosZone.add(new JScrollPane(carreChambre),BorderLayout.CENTER);
		infosZone.add(new JScrollPane(infosPanneauChambre),BorderLayout.WEST);
		infosZone.add(suitesCarre,BorderLayout.SOUTH);
		
		
		PanneauFenetreGestion.add(infosZone, "infos");
		
		
		// Panneaux d'évènements
		JPanel evenementsPanel = new JPanel();
		evenementsPanel.add(new JLabel(" Evenements a venir"));
		PanneauFenetreGestion.add(evenementsPanel,"evenements");
	
		
		
		
		// MENU
		JMenuBar barreMenu = new JMenuBar();
		JMenu menu = new JMenu("Gestion Hotel Celine");
					
		
		JMenuItem itemReservation = new JMenuItem("Réservation de chambre");
		itemReservation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				ReservationChambre fenetreReservation = new ReservationChambre(FenetreGestionHotel.this);
				fenetreReservation.setVisible(true);
			}
			
		});
		menu.add(itemReservation);
		
		JMenuItem itemAttribution = new JMenuItem("Attribution de chambre");
		itemAttribution.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				AttributionChambre fenetreAttribution = new AttributionChambre(FenetreGestionHotel.this);
				fenetreAttribution.setVisible(true);
			}
		});
		menu.add(itemAttribution);
		
		JMenuItem infosItem = new JMenuItem(" Infos Hotel Celine");
		infosItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				FenetreGestionOrganiser.show(PanneauFenetreGestion,"infos");
			}
		});
		menu.add(infosItem);
		
		JMenuItem evenementsItem = new JMenuItem(" Evenements ");
		evenementsItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				FenetreEvenement fenetreEvent = new FenetreEvenement();
				fenetreEvent.setVisible(true);
			}
		});
		menu.add(evenementsItem);
		
		
		barreMenu.add(menu);
		add(PanneauFenetreGestion, BorderLayout.CENTER);
		setJMenuBar(barreMenu);
		
		FenetreGestionOrganiser.show(PanneauFenetreGestion,"infos");
		
		this.setSize(800,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null); 	// Centre la fenetre 
		
		
	}
	
	public void changerCouleurChambre(String numChambre, boolean estReserve) {
	    Component[] composants = carreChambre.getComponents();
	    for (Component composant : composants) {
	        if (composant instanceof JPanel) {
	            JPanel panneauChambre = (JPanel) composant;
	            Component[] composantsPanneau = panneauChambre.getComponents();
	            for (Component composantPanneau : composantsPanneau) {
	                if (composantPanneau instanceof JLabel) {
	                    JLabel labelChambre = (JLabel) composantPanneau;
	                    if (labelChambre.getText().equals(String.valueOf(numChambre))) {
	                        if (estReserve) {
	                            panneauChambre.setBorder(BorderFactory.createLineBorder(Color.RED));
	                        } else {
	                            panneauChambre.setBorder(BorderFactory.createLineBorder(Color.GREEN));
	                        }
	                        panneauChambre.revalidate();
	                        panneauChambre.repaint();
	                        return;
	                    }
	                }
	            }
	        }
	    }
	}


}
