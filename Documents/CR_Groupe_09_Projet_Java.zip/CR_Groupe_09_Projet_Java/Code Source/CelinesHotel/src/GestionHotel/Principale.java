/**
 * 
 */
package GestionHotel;
/**
 * @author Augustin AVOGAN
 *
 */
public class Principale{

	/**
	 * 
	 */
	public Principale() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Authentification fenetreConnexion = new Authentification();
		fenetreConnexion.setVisible(true);


	}

}
