package GestionHotel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.Timer;




public class Authentification extends JFrame implements Serializable{
	
	private JTextField champNom;
	private JPasswordField champMotDePasse;
	private static final long serialVersionUID = 1L;
	private int essais = 0;
	private boolean compteReboursEnCours = false;
	private Timer timer;

	public Authentification() {
		// TODO Auto-generated constructor stub
		setLayout(new BorderLayout());
		
		// Panneau central pour le formulaire de connexion
		JPanel panneauCentral = new JPanel();
		panneauCentral.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5,5,5,5);
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		panneauCentral.add(new JLabel("Nom : "), gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		champNom = new JTextField(15);
		panneauCentral.add(new JLabel("Mot de passe : "), gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 1;
		champMotDePasse = new JPasswordField(15);
		panneauCentral.add(champMotDePasse, gbc);
		
		add(panneauCentral, BorderLayout.CENTER);
		
		 //en tete
		JPanel panneauEnTete = new JPanel();
		panneauEnTete.setBackground(Color.decode("#3498db"));
		JLabel labelTitre = new JLabel("CONNEXION");
		labelTitre.setFont(new Font("Arial", Font.BOLD,24));
		labelTitre.setForeground(Color.WHITE);
		panneauEnTete.add(labelTitre);
		add(panneauEnTete, BorderLayout.NORTH);
		
		// corps
		JPanel panneauCorps = new JPanel();
		panneauCorps.setLayout(new GridLayout(2,2));
		panneauCorps.add(new JLabel("Nom : "));
		champNom = new JTextField();
		panneauCorps.add(champNom);
		panneauCorps.add(new JLabel("Mot de passe : "));
		champMotDePasse = new JPasswordField();
		panneauCorps.add(champMotDePasse);
		add(panneauCorps, BorderLayout.CENTER);
		
		// Bouton de connexion
		JButton boutonConnexion = new JButton("Se Connecter");
		boutonConnexion.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(!compteReboursEnCours) {
					verifierIdentifiants();
				}
			}
			
		});
		add(boutonConnexion, BorderLayout.SOUTH);
		
		// Timer pour le compte à rebours
		timer = new Timer(1000, new ActionListener() {
			private int secondes = 30;
			
			@Override
			public void actionPerformed(ActionEvent e) {
				secondes--;
				if(secondes > 0) {
					boutonConnexion.setText("Veuillez attendre " + secondes + " secondes");
					boutonConnexion.setEnabled(false);
				}else {
					timer.stop();
					compteReboursEnCours = false;
					boutonConnexion.setEnabled(true);
					essais = 0;
				}
			}
		});
		
		setSize(300,150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null); // Centre la fenetre
		
	}
	
	private void verifierIdentifiants() {
		
		String nom = champNom.getText();
		String motDePasse = new String(champMotDePasse.getPassword());
		InputStream is = getClass().getClassLoader().getResourceAsStream("gestionnaires.txt");
		

		
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(is));){
			
			String ligne;
			boolean identifiantsValides = false;
			while((ligne = reader.readLine()) != null) {
				String[] parties = ligne.split(" ");
				if(parties[0].equals(nom) && parties[1].equals(motDePasse)) {
					identifiantsValides = true;
					break;
				}
			}
			
			if(identifiantsValides) {
				JOptionPane.showMessageDialog(Authentification.this,  "Connexion réussie !");
				// Ouvrir la fenetre de gestion de l'hotel
				
				FenetreGestionHotel fenetreGestion = new FenetreGestionHotel();
				fenetreGestion.setVisible(true);
				dispose();
			}else {
				essais++;
				if(essais<3){
					JOptionPane.showMessageDialog(Authentification.this,  "identifiants incorrects. Il vous reste " + (3 - essais) +" essais.");
				}else{
					compteReboursEnCours = true;
					timer.start();
				}
			}
			
		}catch(IOException e) {
			JOptionPane.showMessageDialog(Authentification.this, "Erreur lors de la lecture du fichier gestionnaires.txt");
		}
		
	}
	
	

}
