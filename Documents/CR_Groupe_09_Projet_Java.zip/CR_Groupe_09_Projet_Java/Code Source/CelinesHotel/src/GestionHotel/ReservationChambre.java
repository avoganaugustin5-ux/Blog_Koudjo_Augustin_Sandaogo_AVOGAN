/**
 * 
 */
package GestionHotel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import javax.swing.JOptionPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;





/**
 * @author Augustin AVOGAN
 *
 */
		
		public class ReservationChambre extends JFrame implements Serializable{
			/**
			 * 
			 */
			
			
			private static final long serialVersionUID = 1L;
			public JTextField champNomClient;
			public JTextField champPrenomClient;
			public JTextField champAgeClient;
			public JTextField champSexeClient;
			public JTextField champNationaliteClient;
			public JTextField champProfessionClient;
			public JTextField champNumeroClient;
			public JTextField champDateArrivee;
			public JTextField champDureeSejourClient;
			
			public JTextField champPersonneAprevenirNom;
			public JTextField champPersonneAprevenirNumero;
			public JTextField champPersonneAprevenirProfession;
			public JTextField champPersonneAprevenirAdresse;
			public JTextField champNumeroChambre;
			public JTextField champNombrePersonnes;
			public JTextArea afficheDonnées;
			private JTextArea zoneAffichageReservations;

			
			public String informations = new String();
			String information = new String();
			public String var = new String();
			public String numChambre = new String();
			private FenetreGestionHotel fenetregestionHotel;
			public Set<String> chambresAttribuees = new HashSet<>();
			
			
			
			public ReservationChambre(FenetreGestionHotel fenetreGestionHotel) {
				// TODO Auto-generated constructor stub
				
				

				
				this.fenetregestionHotel = fenetreGestionHotel;
				JButton modifier = new JButton("Modifier");
				JButton supprimer = new JButton("Supprimer");
				setLayout(new BorderLayout());
				
				// Initialisation du JTextArea
				zoneAffichageReservations = new JTextArea(10, 20);
				zoneAffichageReservations.setEditable(false);
				JScrollPane scrollPanes = new JScrollPane(zoneAffichageReservations);
				scrollPanes.setPreferredSize(new Dimension(10, 50)); // Définit la taille préférée du JScrollPane
				add(scrollPanes, BorderLayout.EAST);

				lireChambresOccuppees();
				
				// Formulaire de reservation
				JPanel panneauReservation = new JPanel();
				panneauReservation.setLayout(new GridLayout(15,2));
				
				panneauReservation.add(new JLabel("1: Nom....(Client) :..........................................................................................................................................................................................................."));
				champNomClient = new JTextField();
				panneauReservation.add(champNomClient);
				
				panneauReservation.add(new JLabel("2: Prenom....(Client) :....................................................................................................................................................................................................... "));
				champPrenomClient = new JTextField();
				panneauReservation.add(champPrenomClient);
				
				panneauReservation.add(new JLabel("3: Age....(Client) :.......................................................................................................................................................................................................... "));
				champAgeClient = new JTextField();
				panneauReservation.add(champAgeClient);
				
				panneauReservation.add(new JLabel("4: Sexe....(Client) :......................................................................................................................................................................................................... "));
				champSexeClient = new JTextField();
				panneauReservation.add(champSexeClient);
				
				panneauReservation.add(new JLabel("5: Nationnalite....(Client) :................................................................................................................................................................................................. "));
				champNationaliteClient = new JTextField();
				panneauReservation.add(champNationaliteClient);
				
				panneauReservation.add(new JLabel("6: Profession....(Client)  :.................................................................................................................................................................................................. "));
				champProfessionClient = new JTextField();
				panneauReservation.add(champProfessionClient);
				
				panneauReservation.add(new JLabel("7: Numero....(Client) :....................................................................................................................................................................................................... "));
				champNumeroClient = new JTextField();
				panneauReservation.add(champNumeroClient);
				
				panneauReservation.add(new JLabel("8: Date d'arrivée....(Client) :............................................................................................................................................................................................... "));
				champDateArrivee= new JTextField();
				panneauReservation.add(champDateArrivee);
				
				panneauReservation.add(new JLabel("9: Duree De Sejour....(Client) :.............................................................................................................................................................................................. "));
				champDureeSejourClient = new JTextField();
				panneauReservation.add(champDureeSejourClient);
				
				
				panneauReservation.add(new JLabel("10: Nom Personne A Prevenir En Cas De Besoin :................................................................................................................................................................................. "));
				champPersonneAprevenirNom = new JTextField();
				panneauReservation.add(champPersonneAprevenirNom);
				
				panneauReservation.add(new JLabel("11: Son Numero....(Personne A Prevenir):....................................................................................................................................................................................... "));
				champPersonneAprevenirNumero = new JTextField();
				panneauReservation.add(champPersonneAprevenirNumero);
				
				panneauReservation.add(new JLabel("12: Sa Profession....(Personne A Prevenir) :................................................................................................................................................................................... "));
				champPersonneAprevenirProfession = new JTextField();
				panneauReservation.add(champPersonneAprevenirProfession);
				
				panneauReservation.add(new JLabel("13: Son Adresse....(Personne A Prevenir) :..................................................................................................................................................................................... "));
				champPersonneAprevenirAdresse = new JTextField();
				panneauReservation.add(champPersonneAprevenirAdresse);
				
				panneauReservation.add(new JLabel("14: Numero De Chambre Attribuée :.............................................................................................................................................................................................. "));
				champNumeroChambre = new JTextField();
				panneauReservation.add(champNumeroChambre);
				
				panneauReservation.add(new JLabel("15: Nombre De Personnes dans une chambre :..........................................................................................................................................................................................................."));
				champNombrePersonnes = new JTextField();
				panneauReservation.add(champNombrePersonnes);
				
				
				   // Appel des méthodes pour restreindre la saisie
			    restreindreDate(champDateArrivee);
			    restreindreChiffres(champAgeClient);
			    restreindreChiffres(champDureeSejourClient);
			    restreindreChiffres(champNombrePersonnes);
			    restreindreChiffres(champNumeroChambre);
			    restreindreLettres(champNomClient);
			    restreindreLettres(champPrenomClient);
			    restreindreLettres(champSexeClient);
			    restreindreTelephone(champNumeroClient);
			    restreindreLettres(champNationaliteClient);
			    restreindreLettres(champProfessionClient);
			    restreindreChiffres(champDureeSejourClient);
			    restreindreLettres(champPersonneAprevenirNom);
			    restreindreTelephone(champPersonneAprevenirNumero);
			    restreindreLettres(champPersonneAprevenirProfession);
			    restreindreLettres(champPersonneAprevenirAdresse);
			    restreindreChiffres(champNombrePersonnes);

				
				panneauReservation.setBorder(BorderFactory.createLineBorder(Color.BLACK));

				panneauReservation.setBackground(new Color(173, 216, 230)); // Bleu clair
				
				
				add(panneauReservation, BorderLayout.CENTER);
				
				// Ajouter les écouteurs d'évènements pour les boutons
				
				modifier.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent e) {
				    	
				    	if(verifierChamps()) {
				    		// Récupérer les valeurs
					        String nom = champNomClient.getText();
					        String prenom = champPrenomClient.getText();
					        String age = champAgeClient.getText();
					        String sexe = champSexeClient.getText();
					        String nationnalite = champNationaliteClient.getText();
					        String profession = champProfessionClient.getText();
					        String numero = champNumeroClient.getText();
					        String dateArrivee = champDateArrivee.getText();
					        String dureeSejours = champDureeSejourClient.getText();
					        String nomPAP = champPersonneAprevenirNom.getText();
					        String numeroPAP = champPersonneAprevenirNumero.getText();
					        String professionPAP = champPersonneAprevenirProfession.getText();
					        String adressePAP = champPersonneAprevenirAdresse.getText();
					        String numeroChambre = champNumeroChambre.getText();
					        String nombrePersonnes = champNombrePersonnes.getText();

					        // Créer la chaîne d'information
					        information = "--> Nom...(client) : " + nom + "\n" +
					                "--> Prenom...(client) : " + prenom + "\n" +
					                "--> Age...(client) : " + age + "\n" +
					                "--> Sexe...(client) : " + sexe + "\n" +
					                "--> NationaliteClient...(client) : " + nationnalite + "\n" +
					                "--> ProfessionClient...(client) : " + profession + "\n" +
					                "--> NumeroClient...(client) : " + numero + "\n" +
					                "--> dateArrivee d'arrivée...(client) : " + dateArrivee + "\n" +
					                "--> DureeSejourClient...(client) : " + dureeSejours + "\n\n" +
					                "--> PersonneAprevenirNom : " + nomPAP + "\n" +
					                "--> PersonneAprevenirNumero : " + numeroPAP + "\n" +
					                "--> PersonneAprevenirProfession : " + professionPAP + "\n" +
					                "--> PersonneAprevenirAdresse : " + adressePAP + "\n\n" +
					                "--> Numero De Chambre Attribuée : " + numeroChambre + "\n" + "--> Nombre de Personnes dans la chambre " + numeroChambre + " est : " + nombrePersonnes + "\n\n";

					        // Enregistrer les données
					        enregistrerDonnees(information);

					        // Vider les champs
					        champNomClient.setText("");
					        champPrenomClient.setText("");
					        champAgeClient.setText("");
					        champSexeClient.setText("");
					        champNationaliteClient.setText("");
					        champProfessionClient.setText("");
					        champNumeroClient.setText("");
					        champDateArrivee.setText("");
					        champDureeSejourClient.setText("");
					        champPersonneAprevenirNom.setText("");
					        champPersonneAprevenirNumero.setText("");
					        champPersonneAprevenirProfession.setText("");
					        champPersonneAprevenirAdresse.setText("");
					        champNumeroChambre.setText("");
					        champNombrePersonnes.setText("");
				    		JOptionPane.showMessageDialog(ReservationChambre.this, information);
				    	}
				        
				    }
				});
				
				JButton boutonValider = new JButton("Valider");
				boutonValider.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent e) {
				        if (verifierChamps()) {
				            String nom = champNomClient.getText();
				            String prenom = champPrenomClient.getText();
				            String age = champAgeClient.getText();
				            String sexe = champSexeClient.getText();
				            String nationnalite = champNationaliteClient.getText();
				            String profession = champProfessionClient.getText();
				            String numero = champNumeroClient.getText();
				            String dateArrivee = champDateArrivee.getText();
				            String dureeSejours = champDureeSejourClient.getText();
				            String nomPAP = champPersonneAprevenirNom.getText();
				            String numeroPAP = champPersonneAprevenirNumero.getText();
				            String professionPAP = champPersonneAprevenirProfession.getText();
				            String adressePAP = champPersonneAprevenirAdresse.getText();
				            String numeroChambre = champNumeroChambre.getText();
				            String nombrePersonnes = champNombrePersonnes.getText();
				            // Traitement des données
				            information = "--> Nom...(client) : " + nom + "\n" +
				                    "--> Prenom...(client) : " + prenom + "\n" +
				                    "--> Age...(client) : " + age + "\n" +
				                    "--> Sexe...(client) : " + sexe + "\n" +
				                    "--> NationaliteClient...(client) : " + nationnalite + "\n" +
				                    "--> ProfessionClient...(client) : " + profession + "\n" +
				                    "--> NumeroClient...(client) : " + numero + "\n" +
				                    "--> dateArrivee d'arrivée...(client) : " + dateArrivee + "\n" +
				                    "--> DureeSejourClient...(client) : " + dureeSejours + "\n\n" +
				                    "--> PersonneAprevenirNom : " + nomPAP + "\n" +
				                    "--> PersonneAprevenirNumero : " + numeroPAP + "\n" +
				                    "--> PersonneAprevenirProfession : " + professionPAP + "\n" +
				                    "--> PersonneAprevenirAdresse : " + adressePAP + "\n\n" +
				                    "--> Numero De Chambre Attribuée : " + numeroChambre + "\n" +
				                    "--> Nombre de Personnes dans la chambre " + numeroChambre + " est : " + nombrePersonnes + "\n\n";
				            JOptionPane.showMessageDialog(ReservationChambre.this, information);
				        }
				    }
				});

				
				supprimer.addActionListener(new ActionListener() {
				    @Override
				    public void actionPerformed(ActionEvent e) {
				    	
				        // Récupérer l'identifiant du client à supprimer
				        String idClient = champNumeroClient.getText();

				        // Supprimer les informations du client du fichier
				        File dossierClients = new File("C:\\Users\\Augustin AVOGAN\\eclipse-workspace\\CelinesHotel\\Donnees");
				        if (dossierClients.exists() && dossierClients.isDirectory()) {
				            File[] fichiers = dossierClients.listFiles();
				            if (fichiers != null) {
				                for (File fichier : fichiers) {
				                    if (fichier.getName().contains(idClient)) {
				                        fichier.delete();
				                    }
				                }
				            } else {
				                System.out.println("Aucun fichier trouvé dans le dossier.");
				            }
				        } else {
				            System.out.println("Le dossier n'existe pas ou n'est pas un répertoire.");
				        }
				        
				        String numeChambre = reserverChambre();
						fenetregestionHotel.changerCouleurChambre(numeChambre, false);
				        
				        // Vider les champs
				        champNomClient.setText("");
				        champPrenomClient.setText("");
				        champAgeClient.setText("");
				        champSexeClient.setText("");
				        champNationaliteClient.setText("");
				        champProfessionClient.setText("");
				        champNumeroClient.setText("");
				        champDateArrivee.setText("");
				        champDureeSejourClient.setText("");
				        champPersonneAprevenirNom.setText("");
				        champPersonneAprevenirNumero.setText("");
				        champPersonneAprevenirProfession.setText("");
				        champPersonneAprevenirAdresse.setText("");
				        champNumeroChambre.setText("");
				        
				        enregistrerChambresOccuppees();

				    }
				});
				
				

				
				// Bouton de réservation
				JButton boutonReserver = new JButton("Attribuer");
				
				boutonReserver.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						if(verifierChamps()) {
							String nomClient = champNomClient.getText();
							String prenomClient = champPrenomClient.getText();
							String AgeClient = champAgeClient.getText();
							String SexeClient = champSexeClient.getText();
							String NationaliteClient = champNationaliteClient.getText();
							String ProfessionClient = champProfessionClient.getText();
							String NumeroClient = champNumeroClient.getText();
							var = NumeroClient;
							String dateArrivee = champDateArrivee.getText();
							String DureeSejourClient = champDureeSejourClient.getText();
							
							String PersonneAprevenirNom = champPersonneAprevenirNom.getText();
							String PersonneAprevenirNumero = champPersonneAprevenirNumero.getText();
							String PersonneAprevenirProfession = champPersonneAprevenirProfession.getText();
							String PersonneAprevenirAdresse = champPersonneAprevenirAdresse.getText();
							String NumeroChambre = champNumeroChambre.getText().trim();

					        while (chambresAttribuees.contains(NumeroChambre) || NumeroChambre.isEmpty()) {
					        	NumeroChambre = JOptionPane.showInputDialog(null, 
					                "Numéro déjà attribué ou invalide. Veuillez saisir un autre numéro de chambre :");
					            
					            if (NumeroChambre == null) return; // utilisateur a annulé
					            NumeroChambre = NumeroChambre.trim();
					        }
					        chambresAttribuees.add(NumeroChambre); // on réserve la chambre
							
							
							numChambre = NumeroChambre;
							String NombrePersonnes = champNombrePersonnes.getText();

							
							// Afficher les informations
							afficheDonnées.append("--> Nom...(client) : " + nomClient + "\n");
							afficheDonnées.append("--> Prenom...(client) : " + prenomClient + "\n");
							afficheDonnées.append("--> Age...(client) : " + AgeClient + "\n");
							afficheDonnées.append("--> Sexe...(client) : " + SexeClient + "\n");
							afficheDonnées.append("--> NationaliteClient...(client) : " + NationaliteClient + "\n");
							afficheDonnées.append("--> ProfessionClient...(client) : " + ProfessionClient + "\n");
							afficheDonnées.append("--> NumeroClient...(client) : " + NumeroClient + "\n");
							afficheDonnées.append("--> dateArrivee d'arrivée...(client) : " + dateArrivee + "\n");
							afficheDonnées.append("--> DureeSejourClient...(client) : " + DureeSejourClient + "\n");
							
							afficheDonnées.append("--> PersonneAprevenirNom : " + PersonneAprevenirNom + "\n");
							afficheDonnées.append("--> PersonneAprevenirNumero : " + PersonneAprevenirNumero + "\n");
							afficheDonnées.append("--> PersonneAprevenirProfession : " + PersonneAprevenirProfession + "\n");
							afficheDonnées.append("--> PersonneAprevenirAdresse : " + PersonneAprevenirAdresse + "\n\n");
							afficheDonnées.append("--> Numero De Chambre Attribuée : " + NumeroChambre + "\n");
							afficheDonnées.append("--> Nombre De Personnes dans la Chambre : " + NombrePersonnes + "\n\n");
							//afficheDonnées.append(" \n\n");
							
							informations = "\n Contrat Location de Chambre \n\n--> Nom...(client) : " + nomClient + "\n"+"--> Prenom...(client) : " + prenomClient + "\n"+"--> Age...(client) : " + AgeClient + "\n"+"--> Sexe...(client) : " + SexeClient + "\n"+"--> NationaliteClient...(client) : " + NationaliteClient + "\n"+"--> ProfessionClient...(client) : " + ProfessionClient + "\n"+"--> NumeroClient...(client) : " + NumeroClient + "\n"+"--> dateArrivee d'arrivée...(client) : " + dateArrivee + "\n"+"--> DureeSejourClient...(client) : " + DureeSejourClient + "\n\n"+"--> PersonneAprevenirNom : " + PersonneAprevenirNom + "\n"+"--> PersonneAprevenirNumero : " + PersonneAprevenirNumero + "\n"+"--> PersonneAprevenirProfession : " + PersonneAprevenirProfession + "\n"+"--> PersonneAprevenirAdresse : " + PersonneAprevenirAdresse + "\n\n"+"--> Numero De Chambre Attribuée : " + NumeroChambre + "\n" + "--> Nombre Personnes dans la Chambre : " + NombrePersonnes + "\n";
							
							enregistrerDonnees(informations);
							
							String numeChambre = reserverChambre();
							fenetregestionHotel.changerCouleurChambre(numeChambre, true);
							
							
							// Appel de la classe Facture
					        Facture facture = new Facture(ReservationChambre.this);
					        facture.setVisible(true);
					        
					        afficherMessageReservation();
							
							// Vider les champs
							
							champNomClient.setText("");
							champPrenomClient.setText("");
							champAgeClient.setText("");
							champSexeClient.setText("");
							champSexeClient.setText("");
							champProfessionClient.setText("");
							champNumeroClient.setText("");
							champDateArrivee.setText("");
							champDureeSejourClient.setText("");
							champPersonneAprevenirNom.setText("");
							champPersonneAprevenirNumero.setText("");
							champPersonneAprevenirProfession.setText("");
							champPersonneAprevenirAdresse.setText("");
							champNumeroChambre.setText("");
							champNombrePersonnes.setText("");

							enregistrerChambresOccuppees();
							
							// Stocker les données dans la base de données
							
							try(Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","utilisateur","motDePasse")){
								try(PreparedStatement pstmt = conn.prepareStatement("INSERT INTO reservations (nom_client,prenomClient,AgeClient,SexeClient,NationaliteClient,ProfessionClient,NumeroClient, date_arrivee,DureeSejourClient,PersonneAprevenirNom,PersonneAprevenirNumero,PersonneAprevenirProfession,PersonneAprevenirAdresse,NumeroChambre,NombrePersonnes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")){
									pstmt.setString(1, nomClient);
									pstmt.setString(2, prenomClient);
									pstmt.setString(3, AgeClient);
									pstmt.setString(4, SexeClient);
									pstmt.setString(5, NationaliteClient);
									pstmt.setString(6, ProfessionClient);
									pstmt.setString(7, NumeroClient);
									pstmt.setString(8,  dateArrivee);
									pstmt.setString(9, DureeSejourClient);
									
									
									pstmt.setString(10,  PersonneAprevenirNom);
									pstmt.setString(11,  PersonneAprevenirNumero);
									pstmt.setString(12,  PersonneAprevenirProfession);
									pstmt.setString(13,  NumeroChambre);
									pstmt.setString(14, NombrePersonnes);
									pstmt.executeUpdate();
								}
							}catch(SQLException ex) {
								JOptionPane.showMessageDialog(ReservationChambre.this, "Chambre attribuée !!!  avec succès ! \\n\\n Soyez sans crainte.");}
							}
							JOptionPane.showMessageDialog(ReservationChambre.this, information);
				    	}

				        
				});
				

				
				// Ajouter les composants à la fenetre
				JPanel panneauBouttons = new JPanel();
				panneauBouttons.setLayout(new FlowLayout());
				
				panneauBouttons.add(modifier);
				panneauBouttons.add(supprimer);
				
				panneauBouttons.add(boutonReserver);
				add(panneauBouttons, BorderLayout.SOUTH);
				add(panneauReservation,BorderLayout.NORTH);
				
				// zone de texte pour afficher les informations
				afficheDonnées = new JTextArea(100,30);
				afficheDonnées.setEditable(true);
				
				
				
				JScrollPane scrollPane = new JScrollPane(afficheDonnées);
				scrollPane.setPreferredSize(new Dimension(800, 180)); // Définit la taille préférée du JScrollPane
				add(scrollPane, BorderLayout.EAST);
				
				setSize(800,600);
				setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				setVisible(true);
				
				
			}
						
			public void enregistrerDonnees(String infos) {
			    File Donnees = new File("Donnees");
			    if (!Donnees.exists()) {
			        Donnees.mkdir();
			    }

			    // Utiliser la date et l'heure actuelles pour nommer le fichier
			    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd_HHmmss");
			    String date = format.format(new Date());
			    File fichierClient = new File(Donnees, "clients_" + date + ".txt");

			    try {
			        // Créer un fichier contenant pour écrire dans le fichier
			        FileWriter contenant = new FileWriter(fichierClient, true);
			        // Ecrire les informations du client dans le fichier
			        contenant.write(infos);
			        // Fermer le contenant
			        contenant.close();
			    } catch (IOException e) {
			        System.out.println("Erreur lors de l'enregistrement des données : " + e.getMessage());
			    }
			}
			
			
			private void afficherMessageReservation() {
				
			    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy à HH:mm:ss");
			    String dateHeure = LocalDateTime.now().format(format);
			    JOptionPane.showMessageDialog(this, "1 réservation vient d'être faite le " + dateHeure);
			}
			
			public String getNomClient() {
			    return champNomClient.getText();
			}

			public String getPrenomClient() {
			    return champPrenomClient.getText();
			}

			public String getDureeSejoursClient() {
			    return champDureeSejourClient.getText();
			}

			public String getNombrePersonnes() {
			    return champNombrePersonnes.getText(); // Vous devez créer ce champ si ce n'est pas déjà fait
			}

			public String reserverChambre() {
				return numChambre;
			}
			public static void restreindreChiffres(JTextField textField) {
			    textField.addKeyListener(new KeyAdapter() {
			        @Override
			        public void keyTyped(KeyEvent e) {
			            char c = e.getKeyChar();
			            if (!Character.isDigit(c)) {
			                e.consume();
			            }
			        }
			    });
			}

			// Méthode pour restreindre la saisie aux lettres
			public static void restreindreLettres(JTextField textField) {
			    textField.addKeyListener(new KeyAdapter() {
			        @Override
			        public void keyTyped(KeyEvent e) {
			            char c = e.getKeyChar();
			            if (!Character.isLetter(c)) {
			                e.consume();
			            }
			        }
			    });
			}

			// Méthode pour restreindre la saisie aux dates (chiffres, /, :, -)
			public static void restreindreDate(JTextField textField) {
			    textField.addKeyListener(new KeyAdapter() {
			        @Override
			        public void keyTyped(KeyEvent e) {
			            char c = e.getKeyChar();
			            if (!Character.isDigit(c) && c != '/' && c != ':' && c != '-') {
			                e.consume();
			            }
			        }
			    });
			}

			// Méthode pour restreindre la saisie aux numéros de téléphone
			public static void restreindreTelephone(JTextField textField) {
			    textField.addKeyListener(new KeyAdapter() {
			        @Override
			        public void keyTyped(KeyEvent e) {
			            char c = e.getKeyChar();
			            if (!Character.isDigit(c) && c != ' ' && c != '.' && c != '+' && c != '(' && c != ')') {
			                e.consume();
			            }
			        }
			    });
			}
			public boolean verifierChamps() {
			    if (champNomClient.getText().isEmpty() || champPrenomClient.getText().isEmpty() || champAgeClient.getText().isEmpty() ||champSexeClient.getText().isEmpty() || champProfessionClient.getText().isEmpty() || champNumeroClient.getText().isEmpty() || champDureeSejourClient.getText().isEmpty() || champPersonneAprevenirNom.getText().isEmpty() || champPersonneAprevenirNumero.getText().isEmpty() || champPersonneAprevenirProfession.getText().isEmpty() || champPersonneAprevenirAdresse.getText().isEmpty() || champNumeroChambre.getText().isEmpty() || champNombrePersonnes.getText().isEmpty() || champDateArrivee.getText().isEmpty()) {
			        JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs obligatoires");
			        
			        return false;
			    }
			    // Ajoutez d'autres vérifications ici
			    return true;
			}

			// Méthode pour enregistrer les chambres occupées dans un fichier
			public void enregistrerChambresOccuppees() {
			    try {
			        File fichier = new File("chambres_occupees.txt");
			        if (!fichier.exists()) {
			            fichier.createNewFile();
			        }
			        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fichier))) {
			            for (String numeroChambre : chambresAttribuees) {
			                writer.write(numeroChambre);
			                writer.newLine();
			            }
			        }
			    } catch (IOException e) {
			        System.out.println("Erreur lors de l'enregistrement des chambres occupées : " + e.getMessage());
			    }
			}

			// Méthode pour lire les chambres occupées à partir d'un fichier
			public void lireChambresOccuppees() {
			    try {
			        File fichier = new File("chambres_occupees.txt");
			        if (!fichier.exists()) {
			            fichier.createNewFile();
			        } else {
			            try (BufferedReader reader = new BufferedReader(new FileReader(fichier))) {
			                String ligne;
			                while ((ligne = reader.readLine()) != null) {
			                    if (!ligne.isEmpty()) {
			                        chambresAttribuees.add(ligne);
			                        fenetregestionHotel.changerCouleurChambre(ligne, true);
			                    }
			                }
			            }
			        }
			    } catch (IOException e) {
			        System.out.println("Erreur lors de la lecture des chambres occupées : " + e.getMessage());
			    }
			}


	
		}
