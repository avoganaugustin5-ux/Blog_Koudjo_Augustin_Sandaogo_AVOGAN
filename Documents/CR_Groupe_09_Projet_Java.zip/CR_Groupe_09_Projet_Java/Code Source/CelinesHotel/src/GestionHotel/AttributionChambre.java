/**
 * 
 */
package GestionHotel;
import java.io.Serializable;


import javax.swing.JFrame;


/**
 * @author Augustin AVOGAN
 *
 */
public class AttributionChambre extends ReservationChambre implements Serializable{
	
	private static final long serialVersionUID = 1L;
	

	public AttributionChambre(FenetreGestionHotel fenetreGestionHotel) {
		super(fenetreGestionHotel);
		// TODO Auto-generated constructor stub
		
		setSize(800,600);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		
	}

}
