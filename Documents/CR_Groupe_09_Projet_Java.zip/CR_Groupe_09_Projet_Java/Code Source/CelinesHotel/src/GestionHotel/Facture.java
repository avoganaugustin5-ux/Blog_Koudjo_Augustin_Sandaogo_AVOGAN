/**
 * 
 */
package GestionHotel;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Facture extends JFrame implements Serializable{

    private JTextField champNomClient;
    private JTextField champPrenomClient;
    private JTextField champDureeSejoursClient;
    private JTextField champNombrePersonnes;
    private JTextField champPrixTotalFCFA;
    private JComboBox<String> comboDeviseDepart;
    private JComboBox<String> comboDeviseArrivee;
    private JTextField champPrixDepart;
    private JTextField champPrixArrivee;
    
    private static final long serialVersionUID = 1l;

    public Facture(ReservationChambre reservationChambre) {
        // Initialisation des champs
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2));

        panel.add(new JLabel("Nom client :"));
        champNomClient = new JTextField();
        panel.add(champNomClient);

        panel.add(new JLabel("Prénom client :"));
        champPrenomClient = new JTextField();
        panel.add(champPrenomClient);

        panel.add(new JLabel("Durée séjour :"));
        champDureeSejoursClient = new JTextField();
        panel.add(champDureeSejoursClient);

        panel.add(new JLabel("Nombre de personnes :"));
        champNombrePersonnes = new JTextField();
        panel.add(champNombrePersonnes);

        panel.add(new JLabel("Prix total en F CFA :"));
        champPrixTotalFCFA = new JTextField();
        champPrixTotalFCFA.setEditable(false);
        panel.add(champPrixTotalFCFA);

        String[] devises = {"FCFA", "Euro", "Dollar US", "Livre Sterling", "Yen", "Yuan", "Rouble", "Dirham", "Real", "Rand"};
        panel.add(new JLabel("Devise de départ :"));
        comboDeviseDepart = new JComboBox<>(devises);
        panel.add(comboDeviseDepart);

        panel.add(new JLabel("Prix de départ :"));
        champPrixDepart = new JTextField();
        champPrixDepart.setEditable(false);
        panel.add(champPrixDepart);

        panel.add(new JLabel("Devise d'arrivée :"));
        comboDeviseArrivee = new JComboBox<>(devises);
        panel.add(comboDeviseArrivee);

        panel.add(new JLabel("Prix d'arrivée :"));
        champPrixArrivee = new JTextField();
        champPrixArrivee.setEditable(false);
        panel.add(champPrixArrivee);

        JButton boutonCalculer = new JButton("Calculer");
        boutonCalculer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculerPrixTotal(reservationChambre);
            }
        });
        panel.add(boutonCalculer);

        JButton boutonGenererFacture = new JButton("Générer la facture");
        boutonGenererFacture.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enregistrerFacture();
            }
        });
        panel.add(boutonGenererFacture);

        add(panel, BorderLayout.CENTER);

        afficherInformationsClient(reservationChambre);

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void calculerPrixTotal(ReservationChambre reservationChambre) {
        if (!champDureeSejoursClient.getText().isEmpty()) {
            int dureeSejours = Integer.parseInt(champDureeSejoursClient.getText());
            int prixParNuit = 2500;
            int prixTotalFCFA = dureeSejours * prixParNuit;
            champPrixTotalFCFA.setText(String.valueOf(prixTotalFCFA));

            double tauxDeChangeDepart = getTauxDeChange(comboDeviseDepart.getSelectedItem().toString());
            double prixDepart = prixTotalFCFA / tauxDeChangeDepart;
            champPrixDepart.setText(String.valueOf(prixDepart));

            double tauxDeChangeArrivee = getTauxDeChange(comboDeviseArrivee.getSelectedItem().toString());
            double prixArrivee = prixTotalFCFA / tauxDeChangeArrivee;
            champPrixArrivee.setText(String.valueOf(prixArrivee));
        } else {
            champPrixTotalFCFA.setText("");
            champPrixDepart.setText("");
            champPrixArrivee.setText("");
        }
    }

    private double getTauxDeChange(String devise) {
        switch (devise) {
            case "FCFA":
                return 1;
            case "Euro":
                return 655.957;
            case "Dollar US":
                return 600;
            case "Livre Sterling":
                return 750;
            case "Yen":
                return 5;
            case "Yuan":
                return 90;
            case "Rouble":
                return 10;
            case "Dirham":
                return 65;
            case "Real":
                return 150;
            case "Rand":
                return 40;
            default:
                return 1;
        }
    }

    public void afficherInformationsClient(ReservationChambre reservationChambre) {
        champNomClient.setText(reservationChambre.getNomClient() != null ? reservationChambre.getNomClient() : "Non défini");
        champPrenomClient.setText(reservationChambre.getPrenomClient() != null ? reservationChambre.getPrenomClient() : "Non défini");
        String dureeSejours = reservationChambre.getDureeSejoursClient();
        champDureeSejoursClient.setText(dureeSejours != null && !dureeSejours.isEmpty() ? dureeSejours : "Non défini");
        String nombrePersonnes = reservationChambre.getNombrePersonnes();
        champNombrePersonnes.setText(nombrePersonnes != null && !nombrePersonnes.isEmpty() ? nombrePersonnes : "Non défini");
    }

    private void enregistrerFacture() {
        String nomFichier = "facture_" + System.currentTimeMillis() + ".txt";
        String repertoireFacture = "C:\\Factures"; // Chemin d'accès absolu
        File repertoire = new File(repertoireFacture);
        try {
            if (!repertoire.exists()) {
                if (repertoire.mkdirs()) {
                    System.out.println("Répertoire créé avec succès");
                } else {
                    System.out.println("Erreur lors de la création du répertoire");
                }
            }
            File fichier = new File(repertoire, nomFichier);
            if (fichier.createNewFile()) {
                System.out.println("Fichier créé avec succès");
            } else {
                System.out.println("Fichier déjà existant");
            }
            try (FileWriter writer = new FileWriter(fichier)) {
                writer.write("Nom client : " + champNomClient.getText() + "\n");
                writer.write("Prénom client : " + champPrenomClient.getText() + "\n");
                writer.write("Durée séjour : " + champDureeSejoursClient.getText() + "\n");
                writer.write("Nombre de personnes : " + champNombrePersonnes.getText() + "\n");
                writer.write("Prix total en F CFA : " + champPrixTotalFCFA.getText() + "\n");
                writer.write("Prix de départ en " + comboDeviseDepart.getSelectedItem().toString() + " : " + champPrixDepart.getText() + "\n");
                writer.write("Prix d'arrivée en " + comboDeviseArrivee.getSelectedItem().toString() + " : " + champPrixArrivee.getText() + "\n");
                JOptionPane.showMessageDialog(this, "Facture enregistrée avec succès !");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Erreur lors de l'enregistrement de la facture !" + ex.getMessage());
        }
    }
}
