package GestionHotel;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.YearMonth;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.io.Serializable;



public class FenetreEvenement extends JFrame implements Serializable{

	 private static final long serialVersionUID = 1L;
	 private JTable calendrierTable;  
	 private JTextField jourEvenementField;
	 private JTextArea evenementsArea;

	    
	 public FenetreEvenement() {
	        setLayout(new BorderLayout());

	        // Calendrier
	        calendrierTable = new JTable();
	        afficherCalendrier();
	        add(new JScrollPane(calendrierTable), BorderLayout.CENTER);

	        // Saisie du jour de l'événement
	        JPanel saisiePanel = new JPanel();
	        saisiePanel.add(new JLabel("Jour de l'événement :"));
	        jourEvenementField = new JTextField(5);
	        saisiePanel.add(jourEvenementField);
	        JButton ajouterEvenementButton = new JButton("Ajouter");
	        ajouterEvenementButton.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                ajouterEvenement();
	            }
	        });
	        
	        saisiePanel.add(ajouterEvenementButton);
	        add(saisiePanel, BorderLayout.NORTH);

	        // Zone d'affichage des événements
	        evenementsArea = new JTextArea(10, 20);
	        evenementsArea.setEditable(false);
	        add(new JScrollPane(evenementsArea), BorderLayout.SOUTH);

	        setSize(400, 600);
	        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        setVisible(true);
	 }
	 
	 private void afficherCalendrier() {
	        YearMonth yearMonth = YearMonth.now();
	        int joursDansMois = yearMonth.lengthOfMonth();
	        String[] colonnes = {"Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"};
	        Object[][] donnees = new Object[6][7];

	        int jour = 1;
	        for (int i = 0; i < 6; i++) {
	            for (int j = 0; j < 7; j++) {
	                if (i == 0 && j < yearMonth.atDay(1).getDayOfWeek().getValue() - 1) {
	                    donnees[i][j] = "";
	                } else if (jour <= joursDansMois) {
	                    donnees[i][j] = jour;
	                    jour++;
	                } else {
	                    donnees[i][j] = "";
	                }
	            }
	        }

	        calendrierTable.setModel(new DefaultTableModel(donnees, colonnes));
	    }
	 	
	 private void ajouterEvenement() {
	        try {
	            int jourEvenement = Integer.parseInt(jourEvenementField.getText());
	            evenementsArea.append("Le " + jourEvenement + " du mois, il y a un événement !\n");
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(this, "Veuillez saisir un jour valide");
	        }
	    }
}
